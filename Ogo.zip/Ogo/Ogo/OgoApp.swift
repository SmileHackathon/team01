//
//  OgoApp.swift
//  Ogo
//
//  Created by 児玉拓海 on 2021/12/14.
//

import SwiftUI

@main
struct OgoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
